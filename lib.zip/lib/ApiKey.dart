
class ApiKey{
  static const String key = "AIzaSyA_D5ZIvm2HKPdDaj4ScZBk9nTtL7vc7Do";
  static const String databaseUrl = "https://ebiznes-c9590-default-rtdb.firebaseio.com/";
  static const String apiKey = "pk_test_51J3kMGG5cd9OKvLgVETRfnACB1TK6FLWgthgE8vayoJzKH7LAxoXh4LTPUBSXQB6F7p2oMSQN9l9TChD7op8VH8f00AJSkC6fo";
}